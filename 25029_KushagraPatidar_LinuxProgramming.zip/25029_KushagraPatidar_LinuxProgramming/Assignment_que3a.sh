#!/bin/bash
echo Enter the number
read a
mult=1
echo ''

for (( mult=1; mult<11; mult++ ));
do
	echo $((mult*a))
	#break
done


 




  

 


