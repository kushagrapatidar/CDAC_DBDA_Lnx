#!/bin/bash
echo Enter the number
read n
echo ''
sum=0

for (( i=1; i<=n; i++ ));
do
	sum=$((sum+i))
done

echo "Sum of numbers till $n is: $sum"



 




  

 


