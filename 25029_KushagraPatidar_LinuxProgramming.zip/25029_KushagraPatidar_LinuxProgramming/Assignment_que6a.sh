#!/bin/bash
echo Numbers from 20 to 10
num=20
echo ''

while [ $num -ge 10 ]
do
	echo $num
	num=$((num-1))
done


 




  

 


