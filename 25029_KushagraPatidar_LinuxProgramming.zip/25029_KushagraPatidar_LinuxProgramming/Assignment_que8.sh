#!/bin/bash
echo Enter the Basic Pay
read basic_pay

echo Enter the DA
read da

echo Enter the HRA
read hra

salary=$((basic_pay+da+hra))

echo "Salary: $salary"


 




  

 


