#!/bin/bash
echo "Hello World using \r \v \t \n"
echo
echo "Hello World Normal"
echo "Hello World"
echo
echo "Hello World using \r"
echo -e "Hello \r World"
echo
echo "Hello World using \v"
echo -e "Hello \v World"
echo
echo "Hello World using \t"
echo -e "Hello \t World"
echo 
echo "Hello World using \n"
echo -e "Hello \n World"


 




  

 


